<?php
include './functions.php';

$key = $_GET["key"];





?>


